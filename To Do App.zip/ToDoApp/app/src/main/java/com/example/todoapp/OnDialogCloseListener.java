package com.example.todoapp;

import android.content.DialogInterface;

public interface OnDialogCloseListener {
    public void handleDialogClose(DialogInterface dialog);
}
